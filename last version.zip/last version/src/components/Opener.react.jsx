var React = require('react');
var ReactPropTypes = React.PropTypes;
var DataStoreConstants = require('../constants/DataStoreConstants');
var DataActions = require('../actions/DataActions');

module.exports = React.createClass({
    render: function () {
        return (<input type="file" name="file" onChange={this.handleChange}/>);
    },
    handleChange: function (e) {
        DataActions.openFile(e.currentTarget.files[0]);
    }
});
