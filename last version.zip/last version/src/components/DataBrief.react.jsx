var DataStore = require('../stores/DataStore');
var React = require('react');
var ReactPropTypes = React.PropTypes;
var DataStoreConstants = require('../constants/DataStoreConstants');
var makeUid = require('../utils').makeUid;

function getBriefState() {
    return {
        items: DataStore.getBrief()
    };
}

var DataBrief = React.createClass({
    render: function () {
        var items = this.state.items.map(function (item) {
            return (
                <li key={makeUid(5)}>{item.name}: {item.value}</li>
            );
        });

        return (
            <ul>
                {items}
            </ul>
        );
    },

    getInitialState: function () {
        return {
            items: this.props.items || []
        };
    },

    componentDidMount: function () {
        DataStore.addChangeListener(this._onChange);
    },

    componentWillUnmount: function () {
        DataStore.removeChangeListener(this._onChange);
    },

    _onChange: function () {
        this.setState(getBriefState());
    }
});

module.exports = DataBrief;
