var DataStore = require('../stores/DataStore');
var React = require('react');
var ReactPropTypes = React.PropTypes;
var DataStoreConstants = require('../constants/DataStoreConstants');
var makeUid = require('../utils').makeUid;

var DatePicker = require('react-datepicker');
var moment = require('moment');

var DataActions = require('../actions/DataActions');

require('react-datepicker/dist/react-datepicker.css');

var Select2 = require('./UI/Select.react.jsx');
var Radio = require('./UI/Radio.react.jsx');
var DatesInterval = require('./UI/DatesInterval.react.jsx');

var OKDP = React.createClass({
    propTypes: {
        options: ReactPropTypes.array.isRequired
    },

    render: function () {
        var options = [];
        options['all'] = 'Все отрасли';

        this.props.options.forEach(function (item) {
            options[item.id] = item.name;
        });

        return (
            <div className="form-group">
                <Select2 value={this.state.value} options={options} onChange={this.handleChange}
                         className="form-control">
                </Select2>
            </div>
        );
    },

    getInitialState: function () {
        return {
            value: this.props.value
        }
    },

    componentDidMount: function () {
        DataStore.addChangeListener(this._onDataChange);
    },

    componentWillUnmount: function () {
        DataStore.removeChangeListener(this._onDataChange);
    },

    handleChange: function (value) {
        this.setState({value: value});
        //диспетчеру отправляется сообщение об изменении фильтра по ИНН исполнителя
        DataActions.changeFilter({okdp: value});
    },

    _onDataChange: function () {
        this.setState({
            items: DataStore.getOKDPs(),
            value: DataStore.getOptions().okdp
        });
    }
});

var Performers = React.createClass({
    propTypes: {
        options: ReactPropTypes.array.isRequired
    },

    render: function () {
        var options = [];
        options['all'] = 'Все исполнители';

        this.props.options.forEach(function (item) {
            options[item.id] = `${item.name} (${item.count})`
        });

        return (
            <div className="form-group">
                <Select2 value={this.state.value} options={options} onChange={this.handleChange}
                         className="form-control">
                </Select2>
            </div>
        );
    },

    getInitialState: function () {
        return {
            value: this.props.value
        }
    },

    componentDidMount: function () {
        DataStore.addChangeListener(this._onDataChange);
    },

    componentWillUnmount: function () {
        DataStore.removeChangeListener(this._onDataChange);
    },

    handleChange: function (value) {
        this.setState({value: value});
        //диспетчеру отправляется сообщение об изменении фильтра по ИНН исполнителя
        DataActions.changeFilter({inn: value});
    },

    _onDataChange: function () {
        this.setState({
            items: DataStore.getPerformers(),
            value: DataStore.getOptions().inn
        });
    }
});

var Dates = React.createClass({
    render: function () {
        return (
            <DatesInterval from={this.state.from} to={this.state.to} onChange={this.handleIntervalChange}>
            </DatesInterval>
        );
    },

    getInitialState: function () {
        return DataStore.getDatesDiapazon();
    },

    componentDidMount: function () {
        DataStore.addChangeListener(this._onDataChange);
    },

    _onDataChange: function () {
        this.setState(DataStore.getDatesDiapazon());
    },

    //фильтр меняется не сразу а через небольшой промежуток времени, чтоб пользователь успел исправить данные если ошибся
    handleIntervalChange: function (interval) {
        this.setState(interval);

        this._scheduleFilterChange(interval);

    },
    _scheduleFilterChange: function (interval) {
        clearTimeout(this._timeout);

        this._timeout = setTimeout(function () {
            DataActions.changeFilter(interval);
        }, 1500);
    }
});

var Filters = React.createClass({
    render: function () {
        var modes = {
            'count': 'Количество контрактов',
            'sum': 'Сумма контрактов'
        };

        var changeMode = function (value) {
            DataActions.changeFilter({byPrice: (value === 'sum')});
        };

        return (
            <form>
                <Dates></Dates>
                <Performers options={DataStore.getPerformers()}></Performers>
                <OKDP options={DataStore.getOKDPs()}></OKDP>
                <Radio name="mode" items={modes} onChange={changeMode} value="count"></Radio>
            </form>
        );
    }
});

module.exports = Filters;
