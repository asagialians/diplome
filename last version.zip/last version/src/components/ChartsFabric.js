var React = require('react');
var ReactDOM = require('react-dom');

////// STORES
var DataStore = require('../stores/DataStore');
var PricesStore = require('../stores/PricesStore');
var SectorsStore = require('../stores/SectorsStore');
var TimeStore = require('../stores/TimeStore');
var StatusesStore = require('../stores/StatusesStore');
var ProcStore = require('../stores/ProcStore');

////// Components
var Opener = require('./Opener.react.jsx');
var MainMenu = require('./MainMenu.react.jsx');
var PieChart = require('./PieChart.react.jsx');
var ColumnsChart = require('./ColumnsChart.react.jsx');
var Filters = require('./Filters.react.jsx');
var Contract = require('./Contract.react.jsx');

////// ACTIONS
var DataActions = require('../actions/DataActions');

////// Utils
var makeUid = require('../utils').makeUid;
var moment = require('moment');

var ChartsFabric = {
    getChart: function (name, options) {
        var method = this['_get' + name];

        if (method) {
            return method.call(this, options);
        }
    },

    _getContractsByMonths: function () {
        var onColumnClick = function (column) {
            var dates = {
                from: column.from,
                to: column.to
            };
            DataActions.changeFilter(dates);
        };

        return (
            <ColumnsChart store={TimeStore}
                          onColumnClick={onColumnClick}
                          getStoreData={function (store) {return store.getData()}}>
            </ColumnsChart>
        );
    },

    _getContractsByProcedure: function () {
        var onColumnClick = function (column) {
            DataActions.changeFilter({inn: column.inn});
        };

        return (
            <ColumnsChart store={ProcStore}
                          onColumnClick={onColumnClick}
                          getStoreData={function (store) {return store.getData()}}>
            </ColumnsChart>
        );
    },

    _getContractsBySectors: function () {
        var onColumnClick = function (column) {
            DataActions.changeFilter({okdp: column.OKDP});
        };

        return (
            <PieChart store={SectorsStore}
                      onColumnClick={onColumnClick}
                      getStoreData={function(store){return store.getData();}}>
            </PieChart>
        );
    },

    _getContractsByStatuses: function () {
        return (
            <PieChart store={StatusesStore}
                      getStoreData={function(store){return store.getData();}}>
            </PieChart>
        );
    },

    _getContractsPrices: function () {
        //покажет информацию о контракте в модальном окне
        function showContract(contract_id) {
            //временный контейнер для показа модального окна
            var container = document.createElement('div');
            container.id = 'modal_container-' + makeUid(5);
            document.body.appendChild(container);

            var contract = DataStore.getContractById(contract_id);

            ReactDOM.render(<Contract contract={contract}></Contract>, container);
        }

        var onColumnClick = function (column) {
            showContract(column.contract_id);
        };

        return (
            <ColumnsChart serieName="Contracts"
                          store={PricesStore}
                          onColumnClick={onColumnClick}
                          getStoreData={function (store) {return store.getData()}}>
            </ColumnsChart>
        );
    }
};

module.exports = ChartsFabric;