var React = require('react');
var ReactDOM = require('react-dom');
////// STORES
var DataStore = require('../stores/DataStore');
var PricesStore = require('../stores/PricesStore');
var SectorsStore = require('../stores/SectorsStore');
var TimeStore = require('../stores/TimeStore');
////// Components
var Opener = require('./Opener.react.jsx');
var MainMenu = require('./MainMenu.react.jsx');
var Filters = require('./Filters.react.jsx');
var Contract = require('./Contract.react.jsx');

var ChartsFabric = require('./ChartsFabric');

////// Utils
var urlHash = require('../utils').urlHash;
var moment = require('moment');

require('script!highcharts');
require('script!highcharts/modules/data');

var DataActions = require('../actions/DataActions');

var Application = React.createClass({

    getInitialState: function () {
        return {
            dataIsLoaded: false
        }
    },

    render: function () {
        var menu = [
            {href: "#contracts/statuses", title: "Этапы", text: "Статистика по этапам исполнения"},
            {href: "#contracts/proc", title: "Типы процедур", text: "Статистика по типам процедур у поставщиков"},
            {href: "#contracts/prices", title: "Цены", text: "Анализ цен по каждому из контрактов"},
            {href: "#contracts/months", title: "По месяцам", text: "Помесячная активность заказчиков"}
        ];

        var charts = {};

        if (this.state.dataIsLoaded) {
            charts = this._getCharts(this.state.module);
        } else {
            window.location.hash = '';
        }

        return (
            <div className="application">
                <div className="row">
                    <div className="col-md-4">
                        <MainMenu items={menu} store={DataStore}></MainMenu>
                    </div>
                    <div className="col-md-8">
                        <div>
                            {charts.additionalChart}
                        </div>
                        <div className="panel-body text-center">
                            {charts.filters}
                        </div>
                    </div>
                </div>

                <div>
                    {charts.mainChart}
                </div>
            </div>
        );
    },

    _getCharts: function (module) {
        var mainChart, additionalChart, filters;

        switch (module) {
            case 'contracts/prices':
                mainChart = ChartsFabric.getChart('ContractsPrices');
                additionalChart = ChartsFabric.getChart('ContractsBySectors');
                filters = <Filters></Filters>;
                break;
            case 'contracts/months':
                mainChart = ChartsFabric.getChart('ContractsByMonths');
                additionalChart = ChartsFabric.getChart('ContractsBySectors');
                filters = <Filters></Filters>;
                break;
            case 'contracts/statuses':
                mainChart = ChartsFabric.getChart('ContractsByMonths');
                additionalChart = ChartsFabric.getChart('ContractsByStatuses');
                filters = <Filters></Filters>;
                break;
            case 'contracts/proc':
                mainChart = ChartsFabric.getChart('ContractsByProcedure');
                additionalChart = ChartsFabric.getChart('ContractsBySectors');
                filters = <Filters></Filters>;
                break;
        }

        return {
            mainChart: mainChart,
            additionalChart: additionalChart,
            filters: filters
        };
    },

    componentDidMount: function () {
        window.addEventListener('hashchange', this._handleURIHashChange);

        DataStore.addChangeListener(this._onStoreChange);
    },

    componentWillUnmount: function () {
        window.removeEventListener('hashchange', this._handleURIHashChange);

        DataStore.removeChangeListener(this._onStoreChange);
    },

    _onStoreChange: function () {
        if (!this.state.dataIsLoaded) {
            this.setState({dataIsLoaded: true});
        }
    },

    _handleURIHashChange: function (e) {
        var hash = urlHash();
        this.setState({module: hash});
    }
});

module.exports = Application;
