var DataStore = require('../stores/DataStore');
var React = require('react');
var DataStoreConstants = require('../constants/DataStoreConstants');
var makeUid = require('../utils').makeUid;

var Opener = require('./Opener.react.jsx');
var DataBrief = require('./DataBrief.react.jsx');

var urlHash = require('../utils').urlHash;

//var assign = require('object-assign');

module.exports = React.createClass({
    render: function () {
        var active_href = this.state.active;

        var items = this.state.items.map(function (item) {
            var className = 'list-group-item '
                + ((active_href === item.href) ? 'active' : '')
                + ((item.disabled) ? 'disabled' : '');

            return (
                <a href={item.href} key={makeUid(5)} className={className}>
                    <h4 class="list-group-item-heading">{item.title}</h4>
                    <p class="list-group-item-text">{item.text}</p>
                </a>
            );
        });

        return (
            <div className="list-group">
                <label className="list-group-item">
                    <h4 class="list-group-item-heading">Файл</h4>
                    <Opener store={this.props.store}>
                    </Opener>
                </label>
                <div className="list-group-item">
                    <h4 class="list-group-item-heading">Сводка</h4>
                    <DataBrief store={this.props.store}>
                    </DataBrief>
                </div>
                {items}
            </div>
        );
    },
    getInitialState: function () {
        return {
            items: this.props.items
        }
    },
    componentDidMount: function () {
        var self = this;

        this._handleURIHashChange = function () {
            var hash = '#' + urlHash();
            self.setState({active: hash});
        };

        this._handleURIHashChange();

        window.addEventListener('hashchange', this._handleURIHashChange);
    },
    componentWillUnmount: function () {
        window.removeEventListener('hashchange', this._handleURIHashChange);
    },
    _getItemIndexByHref: function (href) {
        var result = null;
        var items = this.state.items;

        for (var i in items) {
            if (items[i].href === href) {
                result = i;
                break;
            }
        }

        return result;
    }
});