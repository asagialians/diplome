var React = require('react');
var ReactDOM = require('react-dom');
var makeUid = require('../utils').makeUid;
require('script!highcharts');
require('script!highcharts/modules/data');

var DataActions = require('../actions/DataActions');

var moment = require('moment');

var ColumnsChart = React.createClass({
    render: function () {
        return <div style={{width:100+'%'}}></div>
    },

    setData: function (data) {
        var chart = this.chart;

        this.clearChart();

        if (data.categories) {
            chart.xAxis[0].setCategories(data.categories);
        }

        if (data.series) {
            data.series.forEach(function (series) {
                chart.addSeries(series);
            });
        } else {
            if (this.chart.series && this.chart.series.length === 1) {
                this.chart.series[0].setData(data);
            } else {
                console.warn('No series');
            }
        }
    },

    clearChart: function () {
        var chart = this.chart;

        while (chart.series.length) {
            chart.series[0].remove();
        }
    },

    getInitialState: function () {
        return {
            data: this.props.data || [[0, 0]]
        }
    },

    renderChart: function () {
        var self = this;

        this.chart = new Highcharts.Chart({
            chart: {
                renderTo: ReactDOM.findDOMNode(this),
                type: 'column',
                panning: true,
                zoomType: 'xy'
            },
            title: {
                text: this.props.title
            },
            plotOptions: {
                series: {
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                if (self.props.onColumnClick) {
                                    self.props.onColumnClick(this);
                                }
                            }
                        }
                    }
                }
            }
        });
    },

    componentDidUpdate: function () {
        //т.к. реакт сам эти данные не подставит - подставляем их вручную
        this.setData(this._getDataFromStore());
    },

    componentDidMount: function () {
        this.renderChart();
        this.props.store.addChangeListener(this._onDataChange);
        this.setData(this._getDataFromStore());
    },

    componentWillUnmount: function () {
        this.props.store.removeChangeListener(this._onDataChange);
    },

    _onDataChange: function () {
        this.setData(this._getDataFromStore());
    },

    _getDataFromStore: function () {
        return this.props.getStoreData(this.props.store);
    }
});

module.exports = ColumnsChart;
