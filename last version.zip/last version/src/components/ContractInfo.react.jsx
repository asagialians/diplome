var React = require('react');
var moment = require('moment');

module.exports = React.createClass({
    render: function () {
        var contract = this.state.contract;

        var performStartDate = contract.performStartDate ? moment(contract.performStartDate).format('DD.MM.YYYY') : '?';
        var performFinishDate = contract.performFinishDate ? moment(contract.performFinishDate).format('DD.MM.YYYY') : '?';

        return (
            <ul className="list-group">
                <li className="list-group-item">
                    <h4 class="list-group-item-heading">Объект закупки</h4>
                    <p class="list-group-item-text">{contract.object}</p>
                </li>
                <li className="list-group-item">
                    <h4 class="list-group-item-heading">Тип процедуры</h4>
                    <p class="list-group-item-text">{contract.proc_type}</p>
                </li>
                <li className="list-group-item">
                    <h4 class="list-group-item-heading">Организатор</h4>
                    <p class="list-group-item-text">{contract.organizer}</p>
                </li>
                <li className="list-group-item">
                    <h4 class="list-group-item-heading">Заказчик</h4>
                    <p class="list-group-item-text">{contract.customer}</p>
                </li>
                <li className="list-group-item">
                    <h4 class="list-group-item-heading">Лот: Расшифровка ОКПД</h4>
                    <p class="list-group-item-text">{contract.OKDP_descr}</p>
                </li>
                <li className="list-group-item">
                    <h4 class="list-group-item-heading">Даты исполнения</h4>
                    <p class="list-group-item-text">
                        {performStartDate}
                        -
                        {performFinishDate}
                        &nbsp;
                        ({contract.status})
                    </p>
                </li>
            </ul>
        );
    },
    getInitialState: function () {
        return {
            contract: this.props.contract
        }
    }
});