var DataStore = require('../stores/DataStore');
var React = require('react');
var ReactPropTypes = React.PropTypes;
var DataStoreConstants = require('../constants/DataStoreConstants');
var makeUid = require('../utils').makeUid;
require('script!highcharts');
require('script!highcharts/modules/data');

var PieChart = React.createClass({
    render: function () {
        this.id = makeUid(5);
        return <div id={this.id}></div>
    },
    renderChart: function () {
        var self = this;
        
        this.chart = new Highcharts.Chart({
            chart: {
                renderTo: this.id,
                plotShadow: false,
                type: 'pie'
            },
            legend: {
                align: 'center',
                verticalAlign: 'bottom',
                layout: 'horizontal'
            },
            title: {
                text: this.props.title
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                },
                series: {
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                if (self.props.onColumnClick) {
                                    self.props.onColumnClick(this);
                                }
                            }
                        }
                    }
                }
            },
            series: [
                {
                    name: 'Контрактов',
                    colorByPoint: true,
                    data: this.props.data
                }
            ]
        });
    },

    componentDidUpdate: function () {
        //т.к. реакт сам эти данные не подставит - подставляем их вручную
        this.setData(this._getDataFromStore());
    },

    setData: function (data) {
        this.chart.series[0].setData(data);
    },

    componentDidMount: function () {
        this.renderChart();
        this.props.store.addChangeListener(this._onDataChange);
        this.setData(this._getDataFromStore());
    },

    componentWillUnmount: function () {
        this.props.store.removeChangeListener(this._onDataChange);
    },

    _onDataChange: function () {
        var data = this._getDataFromStore();
        //console.log(data);
        this.setData(data);
    },

    _getDataFromStore: function () {
        return this.props.getStoreData(this.props.store);
    }
});

module.exports = PieChart;
