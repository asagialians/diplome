var DataStore = require('../stores/DataStore');
var React = require('react');
var ReactDOM = require('react-dom');
var DataStoreConstants = require('../constants/DataStoreConstants');

var ContractInfo = require('./ContractInfo.react.jsx');

var Contract = React.createClass({
    render: function () {
        var id = 'contract-' + this.state.contract.number;

        return (
            <div className="modal fade" id={id} tabindex="-1" role="dialog"
                 aria-labelledby="myModalLabel">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 className="modal-title" id="myModalLabel">Контракт №{this.state.contract.number}
                                (#{this.state.contract._id})</h4>
                        </div>
                        <div className="modal-body">
                            <ContractInfo contract={this.state.contract}>

                            </ContractInfo>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-default" data-dismiss="modal">Я пони</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    },
    getInitialState: function () {
        return {
            contract: this.props.contract
        }
    },
    componentWillUnmount: function () {
        ReactDOM.findDOMNode(this).parentNode.remove();
    },
    componentDidMount: function () {
        var el = ReactDOM.findDOMNode(this);
        var $el = $(el);
        var container = el.parentNode;

        $el.modal();

        $el.on('hidden.bs.modal', function (e) {
            ReactDOM.unmountComponentAtNode(container);
        })
    }
});

module.exports = Contract;