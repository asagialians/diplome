var React = require('react');
var ReactPropTypes = React.PropTypes;

var Select = React.createClass({
    propTypes: {
        options: ReactPropTypes.array.isRequired
    },

    render: function () {
        var options = [], key;

        for (key in this.props.options) {
            options.push(<option key={key} value={key}>{this.props.options[key]}</option>);
        }

        return (
            <select name={this.props.name} value={this.props.value} className="form-control"
                    onChange={this.handleChange}>
                {options}
            </select>
        );
    },

    handleChange: function (e) {
        this.props.onChange(e.target.value);
    }
});

module.exports = Select;