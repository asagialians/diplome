var React = require('react');
var ReactPropTypes = React.PropTypes;
var makeUid = require('../../utils').makeUid;

var Radio = React.createClass({
    propTypes: {
        items: ReactPropTypes.object.isRequired
    },

    render: function () {
        var inputs = [];

        for (var i in this.props.items) {
            inputs.push(
                <label key={makeUid(5)}>
                    {this.props.items[i]}
                    <input checked={(i === this.state.value)} onChange={this.handleChange} type="radio"
                           name={this.props.name} value={i}/>
                </label>
            );
        }

        return (
            <div className="form-group">
                {inputs}
            </div>
        );
    },

    handleChange: function (e) {
        this.setState({value: e.target.value});
        this.props.onChange(e.target.value);
    },

    getInitialState: function () {
        return {
            value: this.props.value
        }
    }
});

module.exports = Radio;