var React = require('react');
var ReactPropTypes = React.PropTypes;

var DatePicker = require('react-datepicker');
var moment = require('moment');

var DatesInterval = React.createClass({
    propTypes: {
        onChange: ReactPropTypes.func.isRequired
    },

    render: function () {
        return (
            <div className="form-group">
                <DatePicker dateFormat="YYYY-MM-DD" selected={this.props.from}
                            onChange={this.handleDateFromChange}/>
                -
                <DatePicker dateFormat="YYYY-MM-DD" selected={this.props.to}
                            onChange={this.handleDateToChange}/>
            </div>
        );
    },

    handleDateFromChange: function (date) {
        this.props.onChange({
            from: date,
            to: this.props.to
        });
    },

    handleDateToChange: function (date) {
        this.props.onChange({
            from: this.props.from,
            to: date
        });
    }
});

module.exports = DatesInterval;