var keyMirror = require('keymirror');

module.exports = keyMirror({
  DATA_OPEN_FILE: null,
  DATA_SET_OPTIONS: null
});
