//подключение стилей Bootstrap (Webpack создаст для них загрузчик)
require('bootstrap/dist/css/bootstrap.min.css');
require('bootstrap/dist/css/bootstrap-theme.min.css');
require('script!jquery');
require('script!bootstrap/dist/js/bootstrap.min.js');

var React = require('react');
var ReactDOM = require('react-dom');

var moment = require('moment');

var Application = require('./components/Application.react.jsx');

window.onload = function () {
    ReactDOM.render(<Application></Application>, document.getElementById('application-container'));
};
