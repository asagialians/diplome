var AppDispatcher = require('../dispatcher/AppDispatcher');
var DataStoreConstants = require('../constants/DataStoreConstants');

var DataActions = {

    openFile: function (file) {
        AppDispatcher.dispatch({
            actionType: DataStoreConstants.DATA_OPEN_FILE,
            file: file
        });
    },

    changeFilter: function (options) {
        AppDispatcher.dispatch({
            actionType: DataStoreConstants.DATA_SET_OPTIONS,
            options: options
        });
    }
};

module.exports = DataActions;
