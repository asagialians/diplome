var AppDispatcher = require('../dispatcher/AppDispatcher');

var DataStore = require('./DataStore');
var storesFabric = require('./Fabric');
var DataStoreConstants = require('../constants/DataStoreConstants');

var assign = require('object-assign');

/**
 * Хранилище отвечает за статистику по секторам ("пирог")
 * статистика по количеству заключенных контрактов, разбитых по отраслям
 */
var SectorsStore = storesFabric({
    _load: function (DB, options) {
        var where = this.sqlFilter(options, ['okdp']);

        where.push('(contract_date > 0)');

        var whereStr = (where.length > 0 ? 'WHERE ' + where.join(' AND ') : '');

        var y = options.byPrice ? 'SUM(contract_price)' : 'COUNT(*)';

        return DB.select("SELECT OKDP_descr AS name, "
            + y + " AS y, " +
            "FIRST(OKDP) AS `OKDP` " +
            "FROM ? " + whereStr + " GROUP BY OKDP_descr");
    }
});

AppDispatcher.register(function (action) {
    switch (action.actionType) {

        case DataStoreConstants.DATA_SET_OPTIONS:
            SectorsStore.setOptions(action.options);
            break;

    }
});

module.exports = SectorsStore;