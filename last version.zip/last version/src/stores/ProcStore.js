var AppDispatcher = require('../dispatcher/AppDispatcher');

var DataStore = require('./DataStore');
var storesFabric = require('./Fabric');
var DataStoreConstants = require('../constants/DataStoreConstants');

var assign = require('object-assign');

/**
 * По типу процедур сопоставленных с поставщиком.
 * Если у поставщика многовато "Закупки у единственного поставщика" - повод задуматься
 */
var ProcStore = storesFabric({
    _load: function (DB, options) {
        var where = this._where(options),
            whereStr = (where.length > 0 ? 'WHERE ' + where.join(' AND ') : '');

        //для каждого типа процедуры будет отдельная серия в чарте

        var types = DB.select("SELECT DISTINCT proc_type AS `type` FROM ?");

        var y = options.byPrice ? 'SUM(contract_price)' : 'COUNT(*)';

        var categories = DB.select("SELECT DISTINCT performer FROM ? " + whereStr).map(function (row) {
            return row.performer;
        });

        var series = types.map(function (row) {
            var data = categories.map(function (performer) {
                return DB.select(
                    "SELECT " + y + " AS `y`, " +
                    "FIRST(performer) AS name, " +
                    "FIRST(`INN`) AS `inn`" +
                    "FROM ? " +
                    "WHERE (proc_type = '" + row.type + "') AND " +
                    "(performer = '" + performer + "') GROUP BY `inn` LIMIT 1").pop();
            });

            return {
                name: row.type,
                data: data
            }
        });

        return {
            categories: categories,
            series: series
        };
    },

    _where: function (options) {
        var where = this.sqlFilter(options);

        return where;
    }
});

AppDispatcher.register(function (action) {
    switch (action.actionType) {

        case DataStoreConstants.DATA_SET_OPTIONS:
            ProcStore.setOptions(action.options);
            break;

    }
});

module.exports = ProcStore;