var AppDispatcher = require('../dispatcher/AppDispatcher');
var EventEmitter = require('events').EventEmitter;
var DataStoreConstants = require('../constants/DataStoreConstants');
//alasql не может загрузиться обычным образом, поэтому подгружается с помощью script-loader'а
require('script!alasql/dist/alasql.min.js');

var assign = require('object-assign');
var Papa = require('papaparse');

var moment = require('moment');

var CHANGE_EVENT = 'change';

var _data = [];
var _header = {};
var _options = {};

function parseFile(file, success) {
    Papa.parse(file, {
        skipEmptyLines: true,
        header: false,
        complete: function (results, file) {
            success(parseRawData(results));
        }
    });
}

function parseRawData(rows) {
    _header = {};
    var header = rows.data.shift();
    //console.log(rows);

    for (var i in header) {
        _header['col' + i] = header[i];
    }
    console.log(_header);
    var _id = 0;

    _data = rows.data.map(function (row) {
        var rowObj = {
            _id: _id++
        };

        for (var i in row) {
            rowObj['col' + i] = row[i];
        }

        return new Row(_id++, rowObj);
    });
    //console.log(_data);
}

//разобранная строка из файла с данными
var Row = function (id, raw) {
    this._id = id;

    this.number = raw.col0;//Номер закупки
    this.object = raw.col1;//Объект закупки
    this.proc_type = raw.col6;//Тип процедуры
    this.organizer = raw.col11;//Организатор
    this.customer = raw.col47;//Заказчик

    //парсим дату в timestamp
    this.contract_date = raw.col63 ? Date.parse(raw.col63.split('.').reverse().join('-')) : null;//дата подписания контракта - 63 столбец
    this.contractDate = new Date(this.contract_date);

    this.performer = raw.col72;//Поставщик контракта
    this.OKDP = raw.col19;//ОКПД
    this.OKDP_descr = raw.col20;//Расшифровка ОКПД

    this.contractPublishDate = moment(raw.col64, 'DD.MM.YYYY').toDate();//Дата публикации контракта
    this.performStartDate = moment(raw.col65, 'DD.MM.YYYY').toDate();//Дата начала исполнения
    this.performFinishDate = moment(raw.col66, 'DD.MM.YYYY').toDate();//Дата окончания исполнения

    this.status = raw.col67;//Этап исполнения
    if (this.status.length < 2) this.status = 'Нет';

    this.INN = raw.col73;//ИНН исполнителя
    this.organizer_INN = raw.col12;//ИНН организатора

    this.contract_price = parseFloat(raw.col69.replace(' ', '').replace(',', '.'));
    this.initial_price = parseFloat(raw.col51.replace(' ', '').replace(',', '.'));//Начальная цена (руб.)

    this.publishDate = moment(raw.col2, 'DD.MM.YYYY').toDate();//дата публикации
    this.unpublishDate = moment(raw.col3, 'DD.MM.YYYY').toDate();//Дата окончания срока рассмотрения заявок

    this.auctionDate = moment(raw.col4, 'DD.MM.YYYY').toDate();//Дата проведения аукциона

    this.initialProtocolPublishDate = moment(raw.col35, 'DD.MM.YYYY').toDate();//Дата публикации начального протокола
    this.finalProtocolPublishDate = moment(raw.col42, 'DD.MM.YYYY').toDate();//Дата публикации итогового протокола
};

var DataStore = assign({}, EventEmitter.prototype, {
    getData: function () {
        return _data;
    },

    getOptions: function () {
        return _options;
    },

    emitChange: function () {
        this.emit(CHANGE_EVENT);
    },
    addChangeListener: function (callback) {
        this.on(CHANGE_EVENT, callback);
    },
    removeChangeListener: function (callback) {
        this.removeListener(CHANGE_EVENT, callback);
    },
    select: function (query) {
        alasql.fn.ym || (alasql.fn.ym = function (date) {
            if (!date) return null;
            return moment(date).format('YYYY-MM');
        });

        alasql.fn.daysInterval || (alasql.fn.daysInterval = function (date1, date2) {
            return moment(date1).diff(moment(date2), 'days');
        });

        var res = alasql(query, [this.getData()]);
        //console.log(query, res);
        return res;
    },
    //краткая сводка
    getBrief: function () {
        var briefData = {};
        //все контракты
        var briefTotals = this.select("SELECT COUNT(*) as `total_count`, SUM(contract_price) AS total_price FROM ?")[0];
        briefData['Всего контрактов'] = briefTotals.total_count;
        //briefData['Общая сумма всех контрактов'] = briefTotals.total_price;
        //подписанные контракты
        var briefUnsigned = this.select("SELECT COUNT(*) as `signed_count`, SUM(contract_price) AS signed_price FROM ? WHERE contract_date > 0")[0];
        briefData['Подписанных контрактов'] = briefUnsigned.signed_count;
        briefData['Общая сумма подписанных контрактов'] = briefUnsigned.signed_price + ' р.';

        var brief = [];

        for (var i in briefData) {
            brief.push({
                name: i,
                value: briefData[i]
            });
        }

        return brief;
    },
    getPerformers: function () {
        return this.select("SELECT `INN` AS `id`, FIRST(`performer`) AS `name`, COUNT(*) as `count` FROM ? WHERE `INN`<>'' GROUP BY `INN`");
    },
    getOKDPs: function () {
        return this.select("SELECT OKDP AS id, FIRST(OKDP_descr) AS `name` FROM ? GROUP BY OKDP");
    },
    getContractById: function (id) {
        var rows = this.select("SELECT * FROM ? WHERE `_id` = " + id);
        return rows.pop();
    },
    getStats: function (statName, options) {
        options || (options = _options);

        var call = '_stats' + statName;
        if (this[call]) {
            return this[call](options);
        } else {
            console.warn('There is no "' + statName + '" stats;');
        }
        return [];
    },
    //ленивая загрузка диапазона дат
    getDatesDiapazon: function () {
        if (_options.from && _options.to) {
            return {
                from: _options.from,
                to: _options.to
            }
        }

        var dates = this.select("SELECT MAX(contract_date) AS maxd, MIN(contract_date) AS mind FROM ? WHERE contract_date > 0");

        _options.from = moment(dates[0].mind);
        _options.to = moment(dates[0].maxd);

        return {
            from: _options.from,
            to: _options.to
        };
    }
});

AppDispatcher.register(function (action) {
    switch (action.actionType) {

        case DataStoreConstants.DATA_OPEN_FILE:
            parseFile(action.file, function () {
                DataStore.emitChange();
            });
            break;

        case DataStoreConstants.DATA_SET_OPTIONS:
            _options = assign(_options, action.options);
            //console.log(_options);
            DataStore.emitChange();
            break;

    }
});

module.exports = DataStore;
