var DB = require('./DataStore');

var assign = require('object-assign');
var EventEmitter = require('events').EventEmitter;

var CHANGE_EVENT = 'change';

var mkStore = function (loadFunc) {
    //были ли данные уже загружены? Нужно для "ленивой" подгрузки
    var _loaded = false,
    //данные в виде, удобоваримом для Highcharts
        _data = [],
    //фильтры
        _options = {};

    //при изменениях в центральном хранилище нужно переинициализировать это
    DB.addChangeListener(function () {
        //_loaded = false;
    });

    return assign({
        getData: function () {
            if (!_loaded) {
                this.load();
            }

            return _data;
        },
        //установка новых опций (фильтров) приведет к перезагрузке данных
        setOptions: function (options) {
            _options = assign(_options, options);
            _loaded = false;
            this.emitChange();
        },

        emitChange: function () {
            this.emit(CHANGE_EVENT);
        },

        addChangeListener: function (callback) {
            this.on(CHANGE_EVENT, callback);
        },

        removeChangeListener: function (callback) {
            this.removeListener(CHANGE_EVENT, callback);
        },

        load: function () {
            _data = loadFunc.apply(this, [this.DB, _options]);
            _loaded = true;
            this.emitChange();
        },

        sqlFilter: function (options, disable) {
            var disabled;

            if (disable) {
                disabled = function (optName) {
                    return (disable.indexOf(optName) >= 0);
                };
            } else {
                disabled = function (optName) {
                    return false;
                };
            }


            var where = [];

            var from = options.from ? options.from.valueOf() : 0;
            var to = options.to ? options.to.valueOf() : 0;

            if (!disabled('dates') && from && to) {
                where.push("(contract_date BETWEEN '" + from + "' AND '" + to + "')");
            }

            if (!disabled('performer') && options.inn && options.inn != 'all') {
                where.push("(`INN` = '" + options.inn + "')");
            }

            if (!disabled('okdp') && options.okdp && options.okdp != 'all') {
                where.push("(`OKDP` = '" + options.okdp + "')");
            }

            return where;
        }
    }, EventEmitter.prototype);
};

/**
 * Фабрика создаёт типовые хранилища из простых объектов
 *
 * loadFunc - загрузка
 */
var StoresFabric = function (object, loadFunc) {
    object.DB || (object.DB = DB);
    loadFunc || (loadFunc = object._load);

    delete object._load;

    return assign(object, mkStore(loadFunc));
};

module.exports = StoresFabric;