var AppDispatcher = require('../dispatcher/AppDispatcher');

var DataStore = require('./DataStore');
var storesFabric = require('./Fabric');
var DataStoreConstants = require('../constants/DataStoreConstants');

/**
 * Хранилище отвечает за получение статистики по ценам каждого контракта: собственно стоимости и заработка исполнителя за день.
 * Слишком высокие заработки в день могут указывать на коррупционные схемы.
 */
var PricesStore = storesFabric({
    _load: function (DB, options) {
        var where = this._where(options);

        var whereStr = (where.length > 0 ? 'WHERE ' + where.join(' AND ') : '');

        var rows = DataStore.select("" +
            "SELECT " +
            "`_id`, `performer`, `object`, `number`, " +
            "(contract_price / daysInterval(`performFinishDate`, `performStartDate`)) AS y, " +
            "`contract_price` AS `price` " +
            "FROM ? " + whereStr + " ORDER BY y");

        var data = rows.map(function (row) {
            return [row.object, Math.floor(row.y), Math.floor(row.price), row._id];
        });

        var categories = rows.map(function (row) {
            return '№' + row.number;
        });

        return {
            categories: categories,
            series: [
                {
                    name: 'Рублей/день',
                    data: data,
                    keys: ['name', 'y', null, 'contract_id']
                },
                {
                    name: 'Сумма контракта',
                    data: data,
                    keys: ['name', null, 'y', 'contract_id'],
                    visible: false
                }
            ]
        };
    },
    _where: function (options) {
        var where = this.sqlFilter(options);

        where.push('(contract_date > 0)');

        return where;
    }
});

AppDispatcher.register(function (action) {
    switch (action.actionType) {

        case DataStoreConstants.DATA_SET_OPTIONS:
            PricesStore.setOptions(action.options);
            break;

    }
});

module.exports = PricesStore;