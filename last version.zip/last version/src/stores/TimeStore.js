var AppDispatcher = require('../dispatcher/AppDispatcher');

var DataStore = require('./DataStore');
var storesFabric = require('./Fabric');
var DataStoreConstants = require('../constants/DataStoreConstants');

var moment = require('moment');

/**
 * Статистика активности заказчиков помесячно.
 * Пики активности к концу года могут указывать на спешное доосвоение бюджета.
 */
var TimeStore = storesFabric({
    _load: function (DB, options) {
        var where = ['(contract_date > 0)'];
        //фильтрация по исполнителю
        if (options.inn && options.inn != 'all') {
            where.push("(`INN` = '" + options.inn + "')");
        }
        //по организатору
        if (options.organizer_inn && options.organizer_inn != 'all') {
            where.push("(`organizer_INN` = '" + options.organizer_inn + "')");
        }
        //по датам
        /*var from = options.from ? options.from.valueOf() : 0;
         var to = options.to ? options.to.valueOf() : 0;

         if (from && to) {
         where.push("(contract_date BETWEEN '" + from + "' AND '" + to + "')");
         }*/

        var y = options.byPrice ? 'SUM(contract_price)' : 'COUNT(*)';

        var whereStr = (where.length > 0 ? 'WHERE ' + where.join(' AND ') : '');

        var rows = DB.select(
            "SELECT " +
            "MIN(contractDate) AS `date`, " +
            "MAX(contractDate) AS `dateTo`, "
            + y + " AS `y` " +
            "FROM ? " + whereStr + " GROUP BY ym(contractDate) ORDER BY contractDate");

        //TODO: нужно напихать нулевых значений между месяцами, и тогда график будет отображаться правильно
        var data = rows.map(function (row) {
            return [
                parseInt(row.y),
                moment(row.date),
                moment(row.dateTo)
            ];
        });

        var categories = rows.map(function (row) {
            return moment(row.date).format('MMMM, YYYY');
        });

        return {
            categories: categories,
            series: [
                {
                    name: 'Контрактов/месяц',
                    keys: ['y', 'from', 'to'],
                    data: data
                }
            ]
        };
    }
});

AppDispatcher.register(function (action) {
    switch (action.actionType) {

        case DataStoreConstants.DATA_SET_OPTIONS:
            TimeStore.setOptions(action.options);
            break;

    }
});

module.exports = TimeStore;