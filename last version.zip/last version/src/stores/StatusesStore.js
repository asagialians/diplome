var AppDispatcher = require('../dispatcher/AppDispatcher');

var DataStore = require('./DataStore');
var storesFabric = require('./Fabric');
var DataStoreConstants = require('../constants/DataStoreConstants');

var assign = require('object-assign');

/**
 * Статистика по количеству контрактов: заключенных, отклоненных, исполняемых
 */
var StatusesStore = storesFabric({
    _load: function (DB, options) {
        var where = this._where(options),
            whereStr = (where.length > 0 ? 'WHERE ' + where.join(' AND ') : '');

        var y = options.byPrice ? 'SUM(contract_price)' : 'COUNT(*)';

        var data = DB.select(
            "SELECT " +
            y + " AS `y`, " +
            "`status` AS `name` " +
            "FROM ? " + whereStr + " GROUP BY `status`");

        return data;
    },

    _where: function (options) {
        var where = this.sqlFilter(options);

        return where;
    }
});

AppDispatcher.register(function (action) {
    switch (action.actionType) {

        case DataStoreConstants.DATA_SET_OPTIONS:
            StatusesStore.setOptions(action.options);
            break;

    }
});

module.exports = StatusesStore;