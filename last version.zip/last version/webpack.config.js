var IgnorePlugin = require("webpack").IgnorePlugin;
var ContextReplacementPlugin = require("webpack").ContextReplacementPlugin;

module.exports = {
    entry: "./src/index",

    output: {
        path: __dirname + "/dist",
        filename: "app.js"
    },

    plugins: [
        new IgnorePlugin(/(^fs$|xlsx|xls|^path$)/)
    ],

    //watch:true,

    //devtool: "source-map",
    cache: true,

    module: {
        //noParse:[
        ///node_modules/
        //],

        loaders: [
            {
                test: /\.jsx?$/,
                exclude: /(node_modules)/,
                loader: 'babel',
                query: {
                    presets: ["es2015", "react"]
                }
            },
            {test: /\.css$/, loader: "style-loader!css-loader"},
            //{test: /\.png$/, loader: "url-loader?limit=10000"},
            {test: /\.jpg$|.woff$|.woff2$|.eot$|.svg$|.ttf$/, loader: "file-loader"}
        ]
    }
};
